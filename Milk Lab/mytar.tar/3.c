/*
3. Experiment with set user bit.
   Create two users(same rama and krishna).
   rama creates a file junk.txt with permissions rw-------.
   rama creates an executable program to append the string "adding a line" to the file junk.txt.
   Let krishna login and check whether he can append.
   rama changes the permission on the executable program and adds set user bit.
   Let krishna try again. check what happens to the file junk.txt.
*/


