/*
2. A directory has # of text files. 
   a) Combine all of them to create a single file. (like the tar utility)
   b) break the combined files back to the constituent files. (like the untar utility)
*/
