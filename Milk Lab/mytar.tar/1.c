/*
1. experiment:
	a) write the string "I am a fool" to the file descriptor 1
	b) write the string "I am a fool" to the file descriptor 0
	c) read into a char array the string stupid from the file descriptor 0
	d) read into a char array the string stupid from the file descriptor 1
	e) seek to the offset 10000 from the beginning file on the file descriptor 1
*/


























