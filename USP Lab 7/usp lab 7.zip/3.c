/*
	Experiment with close-on-exec (FD_CLOEXEC) flag. 

	Write a program which execs another program. Check if file descriptors remain open across exec call. Set close-on-exec flag in exec-ing process using fcntl system call and observe what happens in exec-ed process.
*/


